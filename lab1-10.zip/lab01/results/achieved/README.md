# Achieved Results folder

This folder is meant to recieve the results of the computations